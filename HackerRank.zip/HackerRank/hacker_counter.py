from collections import Counter
sum = 0
n = int(input())
count_dict = Counter(list(map(int,input().split())))
for _ in range(int(input())):
	size,price=input().split()
	size=int(size)
	price= int(price)
	if count_dict[size] > 0:
		sum = sum + price
		count_dict[size] = count_dict[size] - 1
print(sum)		