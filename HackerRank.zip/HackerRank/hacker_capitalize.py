#!/bin/python3

import math
import os
import random
import re
import sys

# Complete the solve function below.
def solve(s):
    # s=[i.capitalize()if not i.isdigit()  else i  for i in s.split()]
	for i in s.split():
		s= s.replace(i,i.capitalize())
    # s=" ".join(s)
	return(s)

if __name__ == '__main__':
    # fptr = open(os.environ['OUTPUT_PATH'], 'w')

    s = input()

    result = solve(s)
    print(result)
    # fptr.write(result + '\n')

    # fptr.close()
