from fractions import Fraction
from functools import reduce

def product(fracs):
    t = reduce(lambda x,y:x* y,fracs)
    return t.numerator, t.denominator

fracs=[]
for _ in range(int(input())):
     a,b=input().split()
     c=Fraction(int(a),int(b))
     fracs.append(c)
     print(fracs)
(num,denom ) = product(fracs)
print(num,denom)