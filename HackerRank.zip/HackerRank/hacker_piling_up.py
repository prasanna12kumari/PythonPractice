

for _ in range(int(input())):
	m = int(input())
	li = list(map(int,input().split()))

	
	if m %2 ==0:
		a= li[0:int(m/2)]
		b=li[int(m/2):]
	else:
		a= li[0:int(m/2)+1]
		b=li[int(m/2)+1:]	
	# aflag = 0
	# if(all(a[i] >= a[i + 1] for i in range(len(a)-1))): 
		# aflag = 1
	# bflag = 0
	# if(all(b[i] <= b[i + 1] for i in range(len(b)-1))): 
		# bflag = 1
	# if aflag and bflag:
		# print("Yes")
	# else:
		# print("No")
	# print(a)
	# print(b)
	# print(sorted(a,reverse=True))
	# print(sorted(b))
	if  (a == sorted(a,reverse=True)) and (b == sorted(b)):
		print("Yes")
	else:
		print("No")