n= int(input())
for _ in range(n):
	m= int(input())
	li = list(map(int,input().split()))
	print(min([sum([(a*10)+b]) for a in li for b in li if a != b]))