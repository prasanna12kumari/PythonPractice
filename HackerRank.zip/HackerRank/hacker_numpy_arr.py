import numpy
n,m,p=map(int,input().split())
array_1=[]
array_2=[]
for _ in range(n):       
    array_1.append(list(map(int,input().split())))
for _ in range(m):
	array_2.append(list(map(int,input().split())))    

print(numpy.concatenate((array_1, array_2), axis = 0))