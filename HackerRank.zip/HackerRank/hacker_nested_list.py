if __name__ == '__main__':
	
	nestlist=[]
	for _ in range(int(input())):
		list=[]
		name = input()
		score = float(input())
        
		list.append(name)
		list.append(score)
		
		nestlist.append(list)
		
nestlist =  sorted(nestlist,key = lambda x: x[1])
print(nestlist)
namelist=[]
min_val = nestlist[0][1]
second_min=0.0
print(min_val)
for i in range(1,len(nestlist)):
	if i != len(nestlist)-1:
		if(nestlist[i][1] > min_val and nestlist[i][1] <= nestlist[i+1][1]):
			second_min = nestlist[i][1]
			break
	else:
		second_min = nestlist[i][1]
print(second_min)
for i in nestlist:
	if i[1] == second_min:
		namelist.append(i[0])
namelist.sort()
for i in namelist:
	print(i)