from itertools import product

n,m=  map(int,input().split())


newlist = (list(map(int, input().split()))[1:] for _ in range(n))


result = (sum(num**2 for num in numbers) % m for numbers in product(*newlist))
print(max(list(result)))