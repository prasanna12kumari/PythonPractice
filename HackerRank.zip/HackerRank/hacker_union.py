

a,b = [input().split() for _ in range(4)][1::2]

print(len(set(a).union(set(b))))

# Intersection challenge

# a,b = [input().split() for _ in range(4)][1::2]

# print(len(set(a).intersection(set(b))))

# Difference challenge

# a,b = [input().split() for _ in range(4)][1::2]

# print(len(set(a).difference(set(b))))

# Symmetric Difference

# a,b = [input().split() for _ in range(4)][1::2]

# print(len(set(a).symmetric_difference(set(b))))