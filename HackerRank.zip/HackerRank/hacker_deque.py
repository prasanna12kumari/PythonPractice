
from collections import deque
d = deque()
for _ in range(int(input())):
    method, *args = input().split()
    getattr(d, method)(*map(int,args))
print(*d)