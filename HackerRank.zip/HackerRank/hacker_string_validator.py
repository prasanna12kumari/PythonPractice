if __name__ == '__main__':
    s = input()   
    lower = [1 for c in s if c.islower()]
    upper = [1 for c in s if c.isupper()]
	alphanum = [1 for c in s if c.isalnum()]
	alpha = [1 for c in s if c.isalpha()]
	digit = [1 for c in s if c.isdigit()]
	if 1 in alphanum:
		print("True")
	else:
		print("False")
	if 1 in alpha:
		print("True")
	else:
		print("False")
	if 1 in digit:
		print("True")
	else:
		print("False")
	if 1 in lower:
		print("True")
	else:
		print("False")
	if 1 in upper:
		print("True")
	else:
		print("False")

# discussion code
# str = raw_input()
# print any(c.isalnum()  for c in str)
# print any(c.isalpha() for c in str)
# print any(c.isdigit() for c in str)
# print any(c.islower() for c in str)
# print any(c.isupper() for c in str)