from itertools import permutations

s= input().split()
string=s[0]
n=int(s[1])

result = sorted(list(permutations(string,n)))
for i in result:
	print("".join(i))
