m= int(input())
a = input().split()
n= int(input())
b = input().split()
a = set(list(map(int,a)))
b = set(list(map(int,b)))
c  = sorted(list((a.difference(b)).union(b.difference(a))))
for i in c:
	print(i)

# Reduced code
# a,b = [set(raw_input().split()) for _ in range(4)][1::2]
# print '\n'.join(sorted(a^b, key=int))

