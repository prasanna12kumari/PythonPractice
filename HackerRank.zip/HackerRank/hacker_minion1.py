

def minion_game(string):
    # your code goes here    

    vow = 'AEIOU'

    vowscore = 0
    conscore = 0
    for i in range(len(string)):
        if s[i] in vow:
            vowscore += (len(string)-i)
        else:
            conscore += (len(string)-i)

    if vowscore > conscore:
        print("Kevin", vowscore)
    elif vowscore < conscore:
        print("Stuart", conscore)
    else:
        print("Draw")
    
if __name__ == '__main__':
    s = input()
    minion_game(s)