import re
from itertools import groupby

S = input()

group = groupby(S)
group_list=[[item[0] for item in data] for (key, data) in group]
# print(group_list)
new_list=[]
for i in group_list:
	new_set=[]	
	new_set.append(len(i))
	new_set.append(i[0])
	new_list.append(tuple(new_set))
# print(new_list)
		
	
for i in new_list:
	print(i,end="")