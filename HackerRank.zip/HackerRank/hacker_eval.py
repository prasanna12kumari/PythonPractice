str = input().split()

x = int(str[0])
print(eval(input()) == int(str[1]))