import re
# str =input().strip()
# m=re.finditer(r'([!aeiouAEIOU]([aeiouAEIOU]){0,}[!aeiouAEIOU])',str)
# if m:
    # for i in m:
        # print(i.group())
# else:
    # print("-1")

input1 = "match a single character not present in the list below"
input2 = "abaabaabaabaae"
input3 = "abaabaabaabaaei"

# m=re.finditer(r'[?!aeiouAEIOU][?aeiouAEIOU]{0,}[!aeiouAEIOU]+',input3)

# print(m)
# if m:
    # for i in m:
        # print(i.group())
# else:
    # print("-1")

# vowel = "aeiou"
# con = "qwrtypsdfghjklzxcvbnm"
# f = re.findall(r"(?<=[%s])([%s]{2,})[%s]" % (con, vowel, con), input2, re.I)
# if f:
	# for i in f:
		# print(i)
# else:
	# print("-1")

	
 # for x in re.finditer(k,s):
     # print((x.start(),x.end()))
	 
s="aaadaa"
k="aa"
m = re.search(k,s)
print(m.start(),m.end()-1)
for i in range(1,len(s)-1):
	m = re.search(k,s[i:])
	if m:
		print((m.start(),m.end()))
		
	# else:
		# print("no match")
# f=re.findall(k,s)
# if f:
	# for i in f:
		# print(i)
# else:
	# print("-1")
# matches = re.finditer(k,s)
# results = [int(match.group(1)) for match in matches]