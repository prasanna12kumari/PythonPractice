A = input().split()
li = [list(map(int,input().split())) for _ in range(int(input()))]


print(all([ True if any(A) not in i else False for i in li]))
	
