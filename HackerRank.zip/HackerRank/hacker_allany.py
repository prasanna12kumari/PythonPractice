n = input()
l = list(map(int,input().split()))
print(all([ True  if i > 0 else False for i in l ])and any([str(i) == str(i)[::-1] for i in l]))

