s = input().split()
n = int(s[0])
m = int(s[1])

c = '.|.'


for i in range(1,int(n),2):
    print((c*i).center(m,'-'))

print("WELCOME".center(m,'-'))
    
for i in range(int(n)-2,-1,-2):
    print((c*i).center(m,'-'))
