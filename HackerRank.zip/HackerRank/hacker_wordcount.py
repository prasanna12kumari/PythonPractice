


strlist=[]
for _ in range(int(input())):
	str = input()
	strlist.append(str)
finallist=[]
count=0
for i in strlist:
	word_count=[]
	c= strlist.count(i)
	word_count.append(i)
	word_count.append(c)
	finallist.append(word_count)
print(finallist)

newlist=[]
for i in finallist:
	if i not in newlist:
		newlist.append(i)
print(len(newlist))
print(newlist)
for i in newlist:
	print(i[1],end=" ")

