
import re
n = int(input())
for _ in range(n):
    email = input()
    email = email.split()
    if(re.match('<[A-za-z]([\w|\.|-|_])+@[A-Za-z]+\.[A-Za-z]{1,3}>$',email[1])):
        print(email[0],email[1])   
