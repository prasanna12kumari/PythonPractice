
print(len(set([ input()for i in range(int(input()))])))