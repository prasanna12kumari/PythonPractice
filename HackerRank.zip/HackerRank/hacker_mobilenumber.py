import re

for _ in range(int(input())):
    mobno = input()
    if(re.match('^[7|8|9]\d{9}$',mobno)):
        print("YES")
    else:
        print("NO")
