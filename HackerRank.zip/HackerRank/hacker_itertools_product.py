from itertools import product
A= input().split()

B= input().split()
A=[int(i) for i in A]
B=[int(i) for i in B]
l = list(product(A,B))
for i in l:
    print(i,end=" ")

