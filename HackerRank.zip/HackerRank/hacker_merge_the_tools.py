import re

s = input()
n = len(s)
split_string = []
k = int(input())

for i in range(0,n,k):
	str = s[i:i+k]
	str = list(str)
	split_string.append(str)
	
final_list = []
for i in split_string:
	list1 = []
	for e in i:		
		if e not in list1:
			list1.append(e)		
	final_list.append(list1)
for i in final_list:
	str=""
	for j in i:
		str= str +"".join(j)
	print(str)
# Modified Code	
def merge_the_tools(s, k):
    # your code goes here  
    n = len(s)     
    split_string = []    

    for i in range(0,n,k):
        str = s[i:i+k]
        str = list(str)
        split_string.append(str)
        
    final_list = []
    for i in split_string:
        list1 = []
        for e in i:        
            if e not in list1:
                list1.append(e)        
        final_list.append(list1)
    for i in final_list:
        str=""
        for j in i:
            str= str +"".join(j)
        print(str)

if __name__ == '__main__':
    string, k = input(), int(input())
    merge_the_tools(string, k)
		