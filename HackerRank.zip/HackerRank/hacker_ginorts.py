s= list(input())
l,c,o,e="","","",""


for i in s:
    if i.islower():
        l=l+i
    elif i.isupper():
        c=c+i
    elif i.isdigit():
        d= i
        
        if (int(d)%2==0):
            e=e+i
        elif (int(d)%2==1):
            o=o+i
new_string ="".join(sorted(list(l))) +"".join(sorted(list(c))) +"".join(sorted(list(o))) +"".join(sorted(list(e)))
print(new_string)