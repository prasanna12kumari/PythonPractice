from collections import OrderedDict
dict  = OrderedDict()
for _ in range(int(input())):
	item=input()
	itemname = item.rstrip('0123456789').strip()
	price = item[len(itemname):]
	if itemname not in dict:
		dict[itemname] = int(price)
	else:
		dict[itemname] = dict[itemname]+ int(price)
for i, j in dict.items(): 
    print(i,j) 