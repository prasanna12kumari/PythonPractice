def print_rangoli(n):
    # your code goes here
    import string
    char =string.ascii_lowercase
    char=list(char[:n])

    n=len(char)
    d = (((n-1)*2)*2)+1    
    # print(n)
    m = n-1
    for j in range(1,n):    
        start="-".join(char[n-1:n-1-j:-1])
        end = "".join(reversed(start[:-1]))    
        print((start+end).center(d,'-'))
        if j==n-1:
            print((start+"-"+char[0]+"-"+char[1]+end).center(d,'-'))
    for j in range(0,n-1):    
        start="-".join(char[n-1:j:-1])
        end = "".join(reversed(start[:-1]))    
        print((start+end).center(d,'-'))
    

if __name__ == '__main__':
    n = int(input())
    print_rangoli(n)
	
	
