n,m=input().split()
arr=[]
# for i in range(n)
	# arr.append(int(input()))
arr=str(input()).split()

A = set(str(input()).split())
B = set(str(input()).split())
new_list=[]
for i in arr:
	if i not in new_list:
		new_list.append(i)
hap = 0		
for i in new_list:
	if i in A:
		hap = hap+1
	elif i in B:
		hap = hap-1
	else:
		hap = hap
		
print(hap)
		