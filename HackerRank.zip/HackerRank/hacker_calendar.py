import calendar
l=list(map(int,input().split()))
calendar.setfirstweekday(calendar.MONDAY)
n = calendar.weekday(l[2], l[0], l[1])
# print(n)
calen_dict={6:'Sunday',0:'Monday',1:'Tuesday',
    2:'Wednesday',3:'Thursday',4:'Friday',5:'Saturday'}
print(calen_dict[n].upper())