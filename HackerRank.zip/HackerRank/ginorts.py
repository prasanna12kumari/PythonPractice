s= input().split()
l,c,o,e=""
for i in s:
    if i.islower():
        l=l+i
    elif i.isupper():
        c=c+i
    elif i.isdigit():
        d= i
        if (int(d)%2==0):
            e=e+i
        else
            o=o+i
new_string=str(list(l).sort())+
str(list(c).sort())+
str(list(d).sort())+
str(list(e).sort())+
str(list(o).sort()))