

for _ in range(int(input())):
	n = int(input())
	A = input().split()
	m = int(input())
	B = input().split()
	print(all([True if i in B else False for i in A ]))