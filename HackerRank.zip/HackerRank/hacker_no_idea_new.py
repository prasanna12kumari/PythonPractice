
# Reduced code
# arr,a,b=[input().split() if i== 1 else set((input().split())) for i in range(4)][1:]
# print(sum([1  for i in arr if i in a ]+ [-1  for i in arr if i in b]))

# Enter your code here. Read input from STDIN. Print output to STDOUT
n,m=input().split()

arr=str(input()).split()
A = set(str(input()).split())
B = set(str(input()).split())
new_list=[]
for i in arr:
    if i not in new_list:
        new_list.append(i)
hap = 0        
for i in new_list:
    if i in A:
        hap = hap+1
    elif i in B:
        hap = hap-1
    else:
        hap = hap
        
print(hap)
        
