# import re

# is_grouping = re.compile(r'^(?:.{4}\-){3}.{4}$').match
# is_consecutive = re.compile(r'(.)\1{3}').search
# is_valid = re.compile(r'^[456]\d{15}$').match

# for _ in range(int(input())):
    # card_no = input()
    # if is_grouping(card_no):
        # card_no = card_no.replace('-', '')
    # if is_valid(card_no) and not is_consecutive(card_no):
        # print('Valid')
    # else:
        # print('Invalid')
# # Enter your code here. Read input from STDIN. Print output to STDOUT
# My Code
import re
for _ in range(int(input())):        
    cardno =input()
    cardno=cardno.split('-')
    if len(cardno)==1:    
        pattern_match = re.match(r'(^[456](\d){15}$)',cardno[0])
        if pattern_match:
            rep_match = re.findall(r'(([0-9])\2{3,})',cardno[0])
            if rep_match:
                print("Invalid")
            else:
                print("Valid")
		else:
			print("Invalid")
    elif(len(cardno)==4):
        a,b,c,d=len(cardno[0]),len(cardno[1]),len(cardno[2]),len(cardno[3])
        if (a == b == c == d == 4):
            cardno = str(cardno[0])+ str(cardno[1])+ str(cardno[2]) +str(cardno[3])
            pattern_match = re.match(r'(^[456](\d){15}$)',cardno)
            if pattern_match:
                rep_match = re.findall(r'(([0-9])\2{3,})',cardno)
                if rep_match:
                    print("Invalid")
                else:
                    print("Valid")
            else:
                print("Invalid")
        else:
            print("Invalid")
    else:
        print("Invalid")
