import re
		
	
for _ in range(int(input())):        
    id =input()
    pattern_match = re.match(r'^[0-9a-zA-Z]{10}$',id)
    digit_match   = re.findall(r'[0-9]',id)
    uppercase_match = re.findall(r'[A-Z]',id)    
    print(pattern_match)
    print(digit_match)
    print(uppercase_match)   
    flag = 0
    if pattern_match:
	    if(len(digit_match)>=3 and len(uppercase_match)>=2):
		    list = re.findall(r'([A-Z0-9a-z])',id)
		    for i in list:
			    if(list.count(i))>1:
				    flag =1
		    if flag == 1:			
			    print("Invalid")
		    else:
			    print("Valid")
	    else:
		    print("Invalid")
    else:
	    print("Invalid")
		