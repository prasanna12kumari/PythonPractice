	
# from itertools import combinations

# s= input().split()
# string=s[0]
# n=int(s[1])
# for i in range(1,n+1):
	# result = combinations(sorted(string),i)
	# for j in result:
		# print("".join(j))
		
from itertools import combinations_with_replacement

s= input().split()
string=s[0]
n=int(s[1])

result = combinations_with_replacement(sorted(string),n)
for j in result:
	print("".join(j))
		