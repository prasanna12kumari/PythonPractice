if __name__ == '__main__':
    N = int(input())
    newlist=[]
    for _ in range(N):
        cmd = input()
        cmd = cmd.split()
        print(cmd[0])
        if (cmd[0] == "insert"):
            newlist.insert(int(cmd[1]), int(cmd[2])
        elif (cmd[0] == "print"):
            #print(newlist)
        elif (cmd[0] == "remove"):
            newlist.remove(int(cmd[1]))
        elif (cmd[0] == "sort"):
            newlist.sort()
        elif (cmd[0] == "pop"):
            newlist.pop()
        elif (cmd[0] == "reverse"):
            newlist.reverse()
        elif (cmd[0] == "append"):
            newlist.append(int(cmd[1]))