
#My mode
import re

email_list=[]
for _ in range(int(input())):        
    email =input()
    email_list.append(email)
pattern = r'^([\w-])+@([a-zA-Z0-9])+\.([a-zA-z0-9]{1,3})$'

email_list = list(filter(lambda x: re.match(pattern,x), email_list))
print(email_list)

#Modified Code
def fun(s):
    import re
    pattern = r'^([\w-])+@([a-zA-Z0-9])+\.([a-zA-z0-9]{1,3})$'
    if (re.match(pattern,s)):
        return True

    else:
        return False
    # return True if s is a valid email, else return False

def filter_mail(emails):
    return list(filter(fun, emails))

if __name__ == '__main__':
    n = int(input())
    emails = []
    for _ in range(n):
        emails.append(input())

filtered_emails = filter_mail(emails)
filtered_emails.sort()
print(filtered_emails)