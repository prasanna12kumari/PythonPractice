from collections import defaultdict
d= defaultdict(list)


n,m = input().split()
B = []
for i in range(int(n)):
	d[input()].append(i+1)
for i in range(int(m)):
	B.append(input())

for i in B:
	
	if i in d:
		print(" ".join( map(str,d[i]) ))
	else:
		print(-1)