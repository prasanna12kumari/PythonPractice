from collections import OrderedDict

dict = OrderedDict()

for  _ in range(int(input())):
	word = input()
	if word in dict:
		dict[word]=dict[word]+1
	else:
		dict[word]=1
print(len(dict))
for i in dict.values():
	print(i,end=" ")
	
	
	