
n,m=map(int,input().split())
new_list=[]
for _ in range(m):
	new_list.append(list(map(float,input().split())))

for i in zip(*new_list): 
    print( sum(i)/len(i) )