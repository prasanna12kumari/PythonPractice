expect="""Start : html
Start : head
Start : title"""
# End   : title
# End   : head
# Start : body
# -> data-modal-target > None
# -> class > 1
# Start : h1
# End   : h1
# Empty : br
# End   : body
# End   : html"""

mine="""Start :  html
Start :  head
Start :  title"""
# End   : title
# End   : head
# Start :  body
# -> data-modal-target > None
# -> class > 1
# Start :  h1
# End   : h1
# Empty : br
# End   : body
# End   : html"""

if expect == mine:
	print("True")
else:
	print("False")
Start : head	
Start :  head