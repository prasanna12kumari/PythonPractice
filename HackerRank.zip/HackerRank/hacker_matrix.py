#!/bin/python3

import math
import os
import random
import re
import sys



# if __name__ == '__main__':
nm = input().split()

n = int(nm[0])

m = int(nm[1])

matrix = []

for _ in range(n):
	matrix_item = input()
	matrix.append(matrix_item)
# print(matrix)
str=""
for i in range(m):
	for j in range(n):
		str = str + matrix[j][i]    
print(re.sub(r"(?<=[0-9A-Za-z])([#@$%!&\s]+)(?=[0-9A-Za-z])", " ",str))
