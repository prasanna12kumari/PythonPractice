import re
n = """
14
.stitched {
   padding: 20px;
   margin: 10px;
   background: #ff0030;
   color: #fff;
   font-size: 21px;
   font-weight: bold;
   line-height: 1.3em;
   border: 2px dashed #fff;
   border-radius: 10px;
   box-shadow: 0 0 0 4px #ff0030, 2px 1px 6px 4px rgba(10, 10, 0, 0.5);
   text-shadow: -1px -1px #aa3030;
   font-weight: normal;
}  """

# Enter your code here. Read input from STDIN. Print output to STDOUT

# import re
# n = int(input())
# for _ in range(n):
    # line = input()
    # m = re.findall('#([A-Fa-f0-9]{3,6});',line)
    # if m:
        # for i in range(len(m)):
            # print("#"+str(m[i]))

import re
m = re.findall('#([A-Fa-f0-9]{3,6})[;,]',n)
if m:
    for i in range(len(m)):
        print("#"+str(m[i]))