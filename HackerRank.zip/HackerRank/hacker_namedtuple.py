from collections import namedtuple
n= int(input())
column_names=input()
Student= namedtuple('Student',column_names)
print(Student)
sum=0
for i in range(n):
	str=input().split()		
	s1 = Student(str[0],str[1],str[2],str[3])
	sum =sum + int(s1.MARKS)
avg= sum/n
print(avg)