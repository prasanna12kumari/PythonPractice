# nestlist =  sorted(nestlist,key = lambda x: x[1])


import math
import os
import random
import re
import sys
from itertools import groupby
from operator import itemgetter


if __name__ == '__main__':
    s = input()
    s = list(s)
    count_list=[]
    for i in s:
	    list=[]
	    list.append(i)
	    list.append(s.count(i))
	    count_list.append(list)   
    final_list=[]
    for i in count_list:
	    if i not in final_list:
		    final_list.append(i)    
    final_list =sorted(final_list,key = lambda x: x[1],reverse=True)        
    group = groupby(final_list, itemgetter(1))
    grouplist=[[item[0] for item in data] for (key, data) in group]
    grouplist =[sorted(i) for i in grouplist]    
    grouplist=[j for i in grouplist for j in i]    
    for k in range(3):
        for j in final_list:
            if grouplist[k] == j[0]:
                print(grouplist[k],j[1])
			
    
	    
