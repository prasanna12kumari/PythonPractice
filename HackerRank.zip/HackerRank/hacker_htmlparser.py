from html.parser import HTMLParser


class MyHTMLParser(HTMLParser):
    def handle_starttag(self, tag, attrs):
        print("Start :", tag)        
        if len(attrs)>0:
            for i in attrs:
                print("-> " +str(i[0])+" > "+str(i[1]))  
    def handle_endtag(self, tag):
        print("End   :", tag)        
    def handle_startendtag(self, tag, attrs):
        print("Empty :", tag)        
        if len(attrs)>0:
            for i in attrs:
                print("-> " +str(i[0])+" > "+str(i[1]))                

# instantiate the parser and fed it some HTML
n = int(input())
page = []
for line in range(n):
  page.append(str(input()))
parser = MyHTMLParser()
parser.feed("\n".join(page))

