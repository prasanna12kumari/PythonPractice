def count_substring(string, sub_string):
    import re
    count=0
    n = len(sub_string)
    for i in range(len(string)):
        if sub_string == string[i:i+n]:
            print(string[i:i+n],sub_string)
            count=count+1
    return count

if __name__ == '__main__':
    string = input().strip()
    sub_string = input().strip()
    
    count = count_substring(string, sub_string)
    print(count)