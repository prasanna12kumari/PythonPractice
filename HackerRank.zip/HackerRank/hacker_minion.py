import re
def count_substring(string, sub_string):    
    count=0
    n = len(sub_string)
    for i in range(len(string)):
        if sub_string == string[i:i+n]:
            # print(string[i:i+n],sub_string)
            count=count+1
    return count

def minion_game(string):
    # your code goes here
	con = list(set(re.findall(r'[^AEIOU]',string)))
	vow = list(set(re.findall(r'[AEIOU]',string)))
	conlist=[]
	vowlist=[]
	con_score=0
	vow_score=0
	for i in con:
		conlist.append(i)
	n = len(string)	
	for i in range(0,n):
		for j in con:
			if string[i]== j:
				for k in range(i,n):
					str = string[i:i+k]
					if str not in conlist and str != "":
						conlist.append(str)
	for i in vow:
		vowlist.append(i)
	n = len(string)	
	for i in range(0,n):
		for j in vow:
			if string[i]== j:
				for k in range(i,n):
					str = string[i:i+k]
					if str not in vowlist and str != "":
						vowlist.append(str)
						
	if string[0] in con:		
		conlist.append(string)
	if string[0] in vow:
		vowlist.append(string)
	for i in conlist:
		con_score = con_score+count_substring(string,i)
	for i in vowlist:	
		vow_score = vow_score+count_substring(string,i)
	if vow_score > con_score:
		print("Kevin",vow_score)
	elif con_score > vow_score:
		print("Stuart",con_score)
	else:
		print("draw")
if __name__ == '__main__':
    s = input()
    minion_game(s)