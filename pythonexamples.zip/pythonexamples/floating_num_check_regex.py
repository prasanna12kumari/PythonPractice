# import re
# for _ in range(int(input())):
	# print(bool(re.match(r'^[-+]?[0-9]*\.[0-9]+$', input())))
	
	
regex_pattern = r"\.|\,"	# Do not delete 'r'.

import re
print("\n".join(re.split(regex_pattern, input())))



m=re.match(r'[\w{1}]*','Heelooo')