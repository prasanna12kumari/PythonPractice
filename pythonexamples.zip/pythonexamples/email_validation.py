import re
# email = input("Enter Email to test")
email = "prasanna12kumari@gmail.com"

pattern = r'(?P<user_name>.+)@(?P<sub_domain>[A-Za-z0-9.-]+)\.(?P<domain>[A-Za-z]{2,3}|[0-9]{1,3})'
m = re.match(pattern,email)

if m:
	print("Valid Email Address")
	print(m.group())
	print(m.group('user_name'))
	print(m.group('sub_domain'))
	print(m.group('domain'))
else:
	print("No match")
	
	
# matcher= re.compile(r'([a-zA-Z0-9])\1+')
# pattern = re.compile(r'([a-zA-Z0-9])\1+')
# str = "..12345678910111213141516171820212223"
# m=re.match(r'([a-zA-Z0-9])\1+',str)
# m

# [match.group() for match in matcher.finditer('aacbbbqq')]

# m=re.search(r'([a-zA-Z0-9])\1+',str)
# m
# <re.Match object; span=(13, 16), match='111'>
# m.group()
# '111'


str = 'rabcdeefgyYhFjkIoomnpOeorteeeeet'

matcher= re.compile(r'([!aeiouAEIOU]([aeiouAEIOU]+)[!aeiouAEIOU])')
[match.group() for match in matcher.finditer(str)]
m=re.search(r'([!aeiouAEIOU]([aeiouAEIOU])+[!aeiouAEIOU])',str)

re.findall(r'([!aeiouAEIOU]([aeiouAEIOU]+)[!aeiouAEIOU])'',str)



import re

str = 'rabcdeefgyYhFjkIoomnpOeorteeeeet'

m=re.finditer(r'([!aeiouAEIOU]([aeiouAEIOU]){0,}[!aeiouAEIOU])',
str)
if m:
    print(map(lambda x: x.group(),m))
else:
    print("-1")
m=re.finditer(r'([!aeiouAEIOU]([aeiouAEIOU]){0,}[!aeiouAEIOU])',str)
m=re.finditer(r'([!aeiouAEIOU]([aeiouAEIOU]){0,}[!aeiouAEIOU])',input().strip())
if m:
    for i in m:
        print(i.group)
else:
    print("-1")