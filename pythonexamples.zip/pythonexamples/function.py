# import functools

# def add(a,b):
	# return a+b
	
# def mathadd(func,a,b):
	# return functools.partial(func,a,b)
	
# x = mathadd(add,10,20)
# print(x())


# Pass By value since b in integer(immutable) the value of b does not get changed
# b=10
# def add(x):
	# x+=100
	# return x
	
# print(add(b))	# --> 1000
# print(b)		# --> 10

# def add_list(x):
	 # x += [1,2,3,4,5]
	 # return x

# a=[10,20,30]	
# print(add_list(a))
# print(a)

# def updateList(list1):
    # list1 +=[10]
    # return list1
# n = [5, 6]                		# 140312184155336
# print(updateList(n))
# print(n)                      # [5, 6, 10]

# class MyClass:
	# def my_fun():	
		# print("my function")

# def monkey_fun(self):
	# print("monkey function")
# MyClass.my_fun = monkey_fun
# obj = MyClass()
# obj.my_fun()


def func(**args):
	for i,j  in args.items():
		print(i,j)
func(a='hello',b='hi',c='welcome')
	