import requests

# constants
# RUN_URL = u'https://ideas2it-hackerearth.p.rapidapi.com/compile/'
# CLIENT_SECRET = '5db3f1c12c59caa1002d1cb5757e72c96d969a1a'

# source = "print 'Hello World'"

# data = {
    # 'client_secret': CLIENT_SECRET,
    # 'async': 0,
    # 'source': source,
    # 'lang': "PYTHON",
    # 'time_limit': 5,
    # 'memory_limit': 262144,
# }

# r = requests.post(RUN_URL, data=data)


response = requests.post("https://ideas2it-hackerearth.p.rapidapi.com/compile/",
  headers={
    "X-RapidAPI-Key": "401902155cmshac6bf61a79fabfep185b3djsnc1fc3d5dc103",
    "Content-Type": "application/x-www-form-urlencoded"
  },
  params={
    "async": 0,
    "time_limit": 10,
    "memory_limit": 262144,
    "client_secret": "ceaf93f10f7330318aecc742f76bda4fae74b12e",
    "source": "print('Hello Prasanna')",
    "lang": "PYTHON"
  }
)
print(response.json())