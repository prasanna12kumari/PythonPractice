
def convert(s):    
    new = ""    
    for x in s: 
        new += x     
    return new 
# t = input("Enter the number of Test Cases")

D = int(input("Enter the maximum Damage"))

P = input("Enter the String")
strength = 1
damage = 0
for i in P:
	if i == "S":
		damage = damage + strength
	elif i == "C":
		strength = strength * 2
		
print("Instruction:	%s"%P)
print("strength:	%d"%strength)
print("Actual damage:%d"%damage)
print("maximum Damage:%d"%D)

if D <= damage:
	swap_and_solve(P,damage)
else:
	print ("Universe Saved")

def swap_and_solve(P):
	swap_count = 0

	new_P = list(P)
	strength_list = []
	damage_list = []
	swaped_list = []

	for i in range(len(new_P)-2):
		
		t = new_P[i]
		new_P[i]=new_P[i+1]
		new_P[i+1]= t
		strength=1
		damage = 0
		for char in new_P:
			if char == "S":
				damage = damage + strength
			elif char == "C":
				strength = strength * 2
		swap_count = swap_count + 1
		swaped_list.append(convert(new_P))
		strength_list.append(strength)
		damage_list.append(damage)

	print(swap_count,swaped_list,strength_list,damage_list)
