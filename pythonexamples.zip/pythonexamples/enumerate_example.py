import enum
class Animal(enum.Enum): 
    dog = 1
    cat = 2
    lion = 3
	
print(Animal.dog)
print(Animal.dog.name)
print(Animal.dog.value)
print(repr(Animal.dog))

a=['Pen','Pencil']
for i,each in enumerate(a,start=10):
	print('{}.{}'.format(i,each))
	