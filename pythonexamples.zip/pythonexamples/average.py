
a=[10,20,30,40,50]
n = len(a)
avg = sum(a)/n
print(avg)

# k = 60

# avg = (avg*n + k)/n+1
# print(avg)

# avg = (sum(a)+k)/n+1
# print(avg)

# I am going to increase two element by 10
inc =10
no_of_changes =2
a_new = [10,30,40,40,50]
old_avg = sum(a)/n
avg = ((old_avg * n)+(inc*no_of_changes))/n
print(avg)
avg_a_new = sum(a_new)/len(a_new)
print(avg_a_new)


