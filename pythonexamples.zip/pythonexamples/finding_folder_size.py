import os
import sys
directory_size = 0

directory = sys.argv[1]

for (path,dirs,files) in os.walk(directory):
	for file in files:
		filename = os.path.join(path,file)
		directory_size += os.path.getsize(filename)		
		
print(directory_size)

folder_size_dictionary = {'bytes':1,'kilobytes':float(1) / 1024,
	'megabytes':float(1) / (1024*1024),'gigabytes':float(1) / (1024*1024*1024)}

print(folder_size_dictionary)

folder_size_list = []	
for key in folder_size_dictionary:
	folder_size_list.append(str(round(folder_size_dictionary[key]*directory_size,2)))

print(folder_size_list)
	
