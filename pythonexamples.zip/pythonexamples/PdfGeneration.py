

text="""kolkata March 14, 2019
_________________________

22 Carat Gold Rate is  Rs. 31810
24 Carat Gold Rate is Rs. 34021.4"""

def using_report_lab():
	from reportlab.pdfgen import canvas
	 
	c = canvas.Canvas("hello.pdf")
	c.drawString(100,750,"Welcome to Reportlab!")
	c.save()


def using_fpdf():

	from fpdf import FPDF
	 
	pdf = FPDF()
	pdf.add_page()
	pdf.set_font("Arial", size=12)
	pdf.set_text_color(41, 128, 185)
	pdf.cell(200, 10, txt="Gold Price Today", ln=1, align="C")
	pdf.line(50, 20, 160, 20)
	pdf.set_line_width(2)
	pdf.set_draw_color(54,69,79)
	pdf.set_text_color(211, 84, 0)
	
	pdf.cell(0, 10, txt="Kolkata March 14, 2019", ln=33, align="L")
	pdf.set_text_color(39, 174, 96)
	pdf.cell(0, 10, txt="22 Carat Gold Rate is  Rs. 31810", ln=34, align="L")
	pdf.cell(0, 10, txt="24 Carat Gold Rate is Rs. 34021.4", ln=35, align="L")
	pdf.image("Gold.jpg", x=110, y=30,w=50,h=50)
	pdf.output("simple_demo.pdf")
	
	
using_fpdf()