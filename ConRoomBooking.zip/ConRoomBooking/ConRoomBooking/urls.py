
from django.conf.urls import url
from django.contrib import admin
from django.contrib.auth import views as auth_views
from booking import views

urlpatterns = [
	url(r'^$',views.HomeView,name = 'home'),
	url(r'^login/$', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
	url(r'^logout/$', auth_views.LogoutView.as_view(), name='logout'),
	url(r'^booking/$', views.BookingView, name='booking'),
	url(r'^admin/', admin.site.urls),
]
