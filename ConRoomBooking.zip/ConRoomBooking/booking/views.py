from django.shortcuts import render

# Create your views here.
def HomeView(request):
	return render(request,'home.html')

def BookingView(request):
	return render(request,'home.html')