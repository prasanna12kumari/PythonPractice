import requests
r = requests.get('http://127.0.0.1:8000/api/v1/songs')
print(r.text)
print(r.encoding)
print(r.content)
print(r.headers)