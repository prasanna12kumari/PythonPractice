import requests

url = 'http://127.0.0.1:8000/hello/'

headers = {'Authorization': 'Token be28e35a8cbb9c307324bb1f4dd5a1f31bd5c569'}

response = requests.get(url, headers=headers)
response_json = response.json()
print(response.status_code)
print(response_json)
