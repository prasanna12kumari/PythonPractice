from django.contrib import admin
from .models import Songs

# Register your models here.
admin.site.register(Songs)