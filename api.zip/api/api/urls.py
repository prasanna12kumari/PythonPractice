from django.contrib import admin
from django.urls import path,re_path,include
from rest_framework_jwt.views import obtain_jwt_token
from  rest_framework_simplejwt import views as jwt_views

urlpatterns = [
    path('admin/', admin.site.urls),
	# music app
	path('api-token-auth/', obtain_jwt_token, name='create-token'),
	re_path('api/(?P<version>(v1|v2))/', include('music.urls')),
	# core app 
	path('',include('core.urls')),	
	# jwtexample app
	path('api/token/',jwt_views.TokenObtainPairView.as_view(),name = "token_obtain_pair"),
	path('api/token/refresh/',jwt_views.TokenRefreshView.as_view(), name='token_refresh'),
	path('',include('jwtexample.urls')),
]
