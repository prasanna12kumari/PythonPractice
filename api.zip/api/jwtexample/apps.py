from django.apps import AppConfig


class JwtexampleConfig(AppConfig):
    name = 'jwtexample'
