from django import forms
from django.test import TestCase
from ..templatetags.form_tags import field_type,input_class


class ExampleForm(forms.Form):
	name = forms.CharField()
	password = forms.CharField(widget = forms.PasswordInput())
	class Meta:
		field = ('name','password')
		
class FieldTypeTests(TestCase):
	def test_field_widget_type(self):	
		form = ExampleForm()
		self.assertEquals('TextInput',field_type(form['name']))
		self.assertEquals('PasswordInput',field_type(form['password']))
		
class InputClassTest(TestCase):
	def test_unbound_field_initial_state(self):
		form = ExampleForm()
		self.assertEquals('form-control ',input_class(form['name']))
	
	def test_valid_bound_field(self):
		form = ExampleForm({'name':'John','password':'123'})
		print(input_class(form['name']))
		print(input_class(form['password']))
		self.assertEquals('form-control is-valid',input_class(form['name']))
		self.assertEquals('form-control ',input_class(form['password']))
	
	def test_invalid_bound_field(self):
		form = ExampleForm({'name':'','password':'123'})
		self.assertEquals('form-control is-invalid',input_class(form['name']))