class Node:
	def __init__(self,dataval=None):
		self.dataval = dataval
		self.nextval = None

class SLinkedList:
	def __init__(self):
		self.headval=None

list1 = SLinkedList()
list1.headval = Node("Mon")
e2 = Node("Tue")
e3 = Node("Wed")
print(list1.headval)
print(list1.headval.dataval)
print(list1.headval.nextval)
# print(e2.dataval)
# print(e2.nextval)
# print(e3.dataval)
# print(e3.nextval)
list1.headval.nextval = e2
print(list1.headval.dataval)
print(list1.headval.nextval)
e2.nextval=e3
print(e2.dataval)
print(e2.nextval)
e3.nextval=Node("Thursday")
print(e3.dataval)
print(e3.nextval)
