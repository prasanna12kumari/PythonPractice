import sys
save_stdout = sys.stdout
fh=open("out.txt","w")
sys.stdout=fh
print("This line goes to out.txt")
sys.stdout=save_stdout
print("This will be normal")
fh.close()