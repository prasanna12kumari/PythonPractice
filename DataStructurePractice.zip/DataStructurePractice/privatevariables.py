class Parent:
	def __init__(self):
		self.name="Prasanna"
		self.__age=25
		
	def __printname(self):
		print(self.name)
		print(self.__age)
		

class Child(Parent):
	def __init__(self):
		Parent.__init__(self)
		self.address="EBColony"
		
ch = Child()
print(ch.name)
print(ch.address)
print(isinstance(ch,Parent))
print(isinstance(ch,Child))
# print(ch.printname())
par = Parent()
print(par.name)
print(par._Parent__age)
print(par._Parent__printname())
print(isinstance(par,Parent))
print(issubclass(Child,Parent))