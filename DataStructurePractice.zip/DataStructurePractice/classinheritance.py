class Person:

	def __init__(self,name):
		self.name = name
	
	def getName(self):
		return self.name
		
	def isEmployee(self):
		return False
		
class Employee(Person):
	
	def isEmployee(self):
		return True
		
emp = Person("Prasanna")
print(emp.getName())
print(emp.isEmployee())
emp = Employee("Anitha")
print(emp.getName())
print(emp.isEmployee())
		
	