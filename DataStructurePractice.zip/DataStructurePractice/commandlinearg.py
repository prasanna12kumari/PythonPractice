import sys
for i in range(len(sys.argv)):
	print(sys.argv[i])