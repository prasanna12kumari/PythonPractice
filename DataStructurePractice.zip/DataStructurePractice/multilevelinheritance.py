class Parent:
	def __init__(self,name):
		self.name = name
		
	def getName(self):
		return self.name
		
class Child(Parent):
	def __init__(self,name,age):
		Parent.__init__(self,name)
		self.age=age
		
	def getAge(self):
		return self.age
	
class GrandChild(Child):
	def __init__(self,name,age,address):
		Child.__init__(self,name,age)
		self.address=address
	
	def getAddress(self):	
		return self.address
		
c1=GrandChild("Prasanna",25,"EB Colony")
print(c1.getName())
print(c1.getAge())
print(c1.getAddress())