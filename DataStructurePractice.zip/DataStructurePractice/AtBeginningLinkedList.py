class Node:
	def __init__(self,dataval=None):
		self.dataval = dataval
		self.nextval=None
		
class SLinkedList:
	def __init__(self):
		self.headval=None
		
	def listprint(self):
		printval= self.headval
		while printval is not None:
			print(printval.dataval)
			printval = printval.nextval
	
	def AtBeginning(self,newdata):
		NewNode = Node(newdata)
		NewNode.nextval=self.headval
		self.headval=NewNode
		
	def Middle(self,middlenode,newdata):
		if middlenode is  None:
			print("The mentioned node is absent")
			return
		NewNode = Node(newdata)
		
		NewNode.nextval=middlenode.nextval
		middlenode.nextval=NewNode
		
	def last(self,newdata):
		NewNode = Node(newdata)
		if self.headval is None:
			self.headval = NewNode
		last=self.headval
		while(last.nextval):
			last=last.nextval
		last.nextval=NewNode
		
		
list1=SLinkedList()
list1.headval=Node("Mon")
e2 = Node("Tue")
e3 = Node("Wed")
list1.headval.nextval=e2
e2.nextval=e3
e3.nextval=Node("Weddd")
list1.last("Thurs")
list1.AtBeginning("Weekday")
list1.Middle(e3,"Hello")

list1.listprint()
		