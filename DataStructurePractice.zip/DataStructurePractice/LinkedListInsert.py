class Node:
	def __init__(self,dataval=None):
		self.dataval = dataval
		self.nextval = None
class SLinkedList:
	def __init__(self):
		self.headval=None
	
	def listprint(self):
		printval=self.headval
		while printval is not None:
			print(printval.dataval)
			printval= printval.nextval
	
	def AtBeginning(self,newdata):
		NewNode = Node(newdata)
		NewNode.nextval=self.headval
		self.headval= NewNode
		
	def Middle(self,middlenode,newdata):
		NewNode = Node(newdata)
		if middlenode is None:
			print("Node is absent")
			return
		
		NewNode.nextval=middlenode.nextval
		middlenode.nextval=NewNode
		
	def Last(self,newdata):
		NewNode = Node(newdata)
		if self.headval is None:
			self.headval= NewNode
		last = self.headval
		while(last.nextval):
			last=last.nextval
		last.nextval= NewNode
		
list1=SLinkedList()
list1.headval=Node("Mon")

e2=Node("Wed")
list1.headval.nextval=e2

list1.AtBeginning("Sun")
list1.Middle(list1.headval.nextval,"Tue")
list1.Last("Thur")
list1.listprint()