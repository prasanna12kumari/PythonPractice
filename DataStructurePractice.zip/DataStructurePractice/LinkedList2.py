class Node:
	def __init__(self,dataval=None):
		self.dataval = dataval
		self.nextval = None
class SLinkedList:
	def __init__(self):
		self.headval=None
		
	def listprint(self):
		printval = self.headval
		while printval is not None:
			print(printval.dataval)
			printval = printval.nextval
			
	def AtBeginning(self,newdata):
		NewNode = Node(newdata)
		NewNode.nextval = self.headval
		self.headval=NewNode
		
	def middle(self,middlenode,newdata):
		NewNode = Node(newdata)
		if middlenode is None:
			print("Node is absent")
			return
		NewNode.nextval=middlenode.nextval
		middlenode.nextval=NewNode
	
	def last(self,newdata):
		NewNode = Node(newdata)		
		if self.headval is None:
			NewNode.nextval=self.headval
			self.headval = NewNode
		last = self.headval
		while (last.nextval)
			last=last.nextval
		last.nextval=NewNode
	
	def remove(self,data):
		Headval= self.headval
		if Headval.dataval== data:
			Headval = 