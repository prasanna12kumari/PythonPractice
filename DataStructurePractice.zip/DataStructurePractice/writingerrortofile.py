import sys
save_stderr=sys.stderr
fh=open("error.txt","w")
sys.stderr =fh
x=10/0

print("normal")
fh.close()