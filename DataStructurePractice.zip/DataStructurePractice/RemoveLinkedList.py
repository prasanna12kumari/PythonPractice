class Node:
	def __init__(self,dataval = None):
		self.dataval = dataval
		self.nextval = None
		
class SLinkedList:
	def __init__(self):
		self.headval=None
		
	def AtBeginning(self,newdata):
		NewNode = Node(newdata)
		NewNode.nextval=self.headval
		self.headval=NewNode
		
	def listprint(self):
		printval=self.headval
		while printval is not None:
			print(printval.dataval)
			printval=printval.nextval
			
	def Remove(self,Removekey):
		Headval= self.headval
		if Headval is not None:			
			if Headval.dataval==Removekey:
				print("firsttime")
				self.headval = Headval.nextval
				Headval=None
				return
		i=0	
		while(Headval is not None):
			if Headval.dataval == Removekey:
				i=i+1
				print(i)
				break
			prev=Headval
			Headval=Headval.nextval
		if Headval is None:
			return
		
		prev.nextval=Headval.nextval
		Headval = None
	def Update(self,data,newdata):
		Headval=self.headval
		while Headval is not None:
			if Headval.dataval==data:
				Headval.dataval=newdata
				return
			Headval=Headval.nextval
				
		
list1=SLinkedList()
list1.AtBeginning("Mon")
list1.AtBeginning("Tue")
list1.AtBeginning("Wed")
# list1.listprint()
# list1.Remove("Wed")
list1.listprint()
list1.Update("Tue","Tuesday")
list1.listprint()
