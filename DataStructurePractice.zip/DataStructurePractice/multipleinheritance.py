class Base1:

	def __init__(self):	
		self.str1 = "Prasanna"
		
class Base2:

	def __init__(self):
		self.str2 = "Kumari"
		
class Derived(Base1,Base2):

	def __init__(self):
		Base1.__init__(self)
		Base2.__init__(self)
		
	def printstr(self):
		print(self.str1)
		print(self.str2)
		# return True By default function will return None
d1 = Derived()
print(d1.printstr())