class Node:
	def __init__(self,dataval=None):
		self.dataval=dataval
		self.nextval=None
		self.prevval=None

class DLinkedList:
	def __init__(self):
		self.headval=None
		
	def push(self,newdata):
		NewNode = Node(newdata)
		NewNode.nextval = self.headval
		print(self.headval)
		if self.headval is not None:
			self.headval.prevval=NewNode
		self.headval=NewNode
		
	def listprint(self):
		printval=self.headval
		while printval is not None:
			print(printval.dataval)
			printval=printval.nextval
			
list1=DLinkedList()
list1.headval = Node("Sun")
list1.push("Mon")
list1.push("Tue")
list1.push("Wed")
list1.listprint()